This is a java code project originally built and run through the Eclipse IDE.

Some modifications may be needed to run this software through a different IDE
or through the console.