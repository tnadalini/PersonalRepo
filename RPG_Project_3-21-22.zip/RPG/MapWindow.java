import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.text.DefaultCaret;

public class MapWindow extends JFrame implements KeyListener {
	
	private static final long serialVersionUID = 1L;
	
	private static JTextArea output;
	//private static Thread t1;
	//private static Thread t2;
	//private static int key = 0; //key pressed by the user
	public Player player;
	Game game;
	
	

	public MapWindow(String name, Player p, Game g) {
		super(name);
		player = p;
		game = g;
		
		output = new JTextArea(50,50);
		DefaultCaret caret = (DefaultCaret) output.getCaret();
		caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
		
		//output.append(");
		
		getContentPane().add(new JScrollPane(output));
		setSize(500,500);
		setVisible(true);
		
		output.addKeyListener(this);
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
	}
	
	public JTextArea getOutput() {
		return output;
	}
	
	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyChar() == 'h') { //open the help menu
			HelpWindow help = new HelpWindow("Help Menu"); //open up a new help window
		}
		else if (e.getKeyChar() == 'c') {
			ControlsWindow c = new ControlsWindow("Controls Menu");
		}
	}
	
	@Override
	public void keyReleased(KeyEvent e) {
		//output.append("" + e.getKeyChar() + "\n");
	}
	
	private void checkKeyEvent(KeyEvent e) {
	}
	

}