//Space object that is used in all room objects
//type indicates whether the player can move to the spot and if the spot contains an enemy/item
public class Space {
	
	private Space front, left, right, back; //track other spaces near it (for movement)
	//true = valid space for player to move (blank or type inside), false = void/null space (X)
	private boolean valid; 
	
	// types: 0 = null space (X), 1 = open space (O), 2 = 'boss' fight space (!!), 
			//3 = enemy/fight space (!), 4 = item space (?),
			//5 = treasure chest space ($), 6 = exit space (>,<,v,^)
			//7 = Player space - marks the current location of the player
	private int type;
	
	//constructors
	public Space() { //default space constructor 
		front = null;
		left = null;
		right = null;
		back = null;
		valid = false;
		type = 0;
	} 
	
	public Space(Space f, Space l, Space r, Space b, boolean boo, int t) { //specialized constructor
		front = f;
		left = l;
		right = r;
		back = b;
		valid = boo;
		type = t;
	}
	
	//getters
	public Space getFront() {
		return this.front;
	}
	
	public Space getLeft() {
		return this.left;
	}
	
	public Space getRight() {
		return this.right;
	}
	
	public Space getBack() {
		return this.back;
	}
	
	public boolean getValid() {
		return this.valid;
	}
	
	public int getType() {
		return this.type;
	}
	
	
	//setters
	public void setFront(Space f) {
		front = f;
	}
	
	public void setLeft(Space l) {
		left = l;
	}
	
	public void setRight(Space r) {
		right = r;
	}
	
	public void setBack(Space b) {
		back = b;
	}
	
	public void setValid(boolean boo) {
		valid = boo;
	}
	
	public void setType(int t) {
		type = t;
	}
	
	
	// types: 0 = null space (X), 1 = open space (O), 2 = 'boss' fight space (!!), 
			//3 = enemy/fight space (!), 4 = item space (?),
			//5 = treasure chest space ($), 6 = exit space (>,<,v,^)
	@Override
	public String toString() {
		String str = "";
		switch (this.type) {
		case 0:
			str = "X";
			break;
		case 1: 
			str = "O";
			break;
		case 2:
			str = "!!";
			break;
		case 3:
			str = "!";
			break;
		case 4:
			str = "?";
			break;
		case 5: 
			str = "$";
			break;
		case 6:
			str = "<>";
			break;
		case 7:
			str = "P";
			break;
		}
		return str;	
	}
	
	
	
}