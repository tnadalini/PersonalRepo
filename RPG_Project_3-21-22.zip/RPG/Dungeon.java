
public class Dungeon {
	
	public Room[] rooms; //array of Rooms contained within the dungeon
	public int size; //number of rooms in the dungeon
	
	public Dungeon(int s) { //size of dungeon is given
		this.size = s;
		rooms = new Room[size]; //adjust array size accordingly
		
		for (int i = 0; i < size; i++) {
			rooms[i] = new Room(1); //fill each Room space with a new Room  
		}
	}

}
