//Room object that contains an array of 25 'Spaces'
//All dungeons will contain a certain number of these rooms that the player must navigate through
public class Room {
	public Space[] spaces = new Space[25]; //length is always 25 (0-24)
	private int type; //5 types of rooms
	public int start, exit; //index value for where the player will start moving from
					  		//also indicates where the exit space is located
	
	public int pSpace; //for holding the index location of the player 
	
	public Room() {
		//blank
	}
	
	public Room(int type) { //makes a room based off given room type (int)
		this.type = type;
		for (int i = 0; i < 25; i++) {
			this.spaces[i] = new Space();
		}
		System.out.println("End of constructor");
		fillRoom(type);
	}
	
	//method to get a random space type (all types)
	private int getRandomType() {
		//rates: (65% blank/open space, 1% boss fight, 25% normal enemy, 
				//7% item, 2% treasure chest)
		// types: 0 = null space (X), 1 = open space (O), 2 = 'boss' fight space (!!), 
        		//3 = enemy/fight space (!), 4 = item space (?),
				//5 = treasure chest space ($), 6 = exit space (>,<,v,^)
		
		//Min + (int)(Math.random() * ((Max - Min) + 1)) - getting random int within range (1-100)
		int i = 1 + (int) (Math.random() * ((100 - 1) + 1));
		
		if (i <= 65) { //blank space (1-65)
			return 1;
		}
		else if (i >= 76) { //normal enemy space (76-100)
			return 3;
		}
		else if (i >= 66 && i <= 72) { //item space (66-72)
			return 4;
		}
		else if (i == 73 || i == 74) { //treasure chest space (73, 74)
			return 5;
		}
		else if (i == 75) { //boss spot (75)
			return 2;
		}
		//in case of error, just return 1 for a blank space
		return 1;
	}
	
	private int getTreasureSpace() { //for spaces that are designated for treasure
		//rates: (30% treasure, 50% item, 20% blank space)
		int i = 1 + (int) (Math.random() * ((10 - 1) + 1)); //random int between (1-10)
		if (i <= 3) { //treasure space (1-3)
			return 5;
		}
		else if (i > 3 && i < 9) { //item space (4-8)
			return 4;
		}
		else { //blank space (9, 10)
			return 1;
		}
		
	}

	
	private void fillRoom(int type) {
		//createRoom();
		System.out.println("fill room");
		switch (type) {
		case 1: 
			System.out.println("Creating room of type 1");
			createRoom1(); //'abyss' with bridge in middle
			break;
		case 2: 
			createRoom2(); //room with scattered holes in ground
			break;
		case 3:
			createRoom3(); //'L' shaped room with a single bridge to small platform
			break;
		case 4:
			createRoom4(); //'narrow path' room with two bridges
			break;
		case 5:
			createRoom5(); //'boss fight' room
			break;
		default:
			throw new IllegalArgumentException("Invalid Room type int received!");
		} //end switch
		
	} //end fillRoom
	
//	private void createRoom() {
//		//filler so Spaces wont throw errors during specialized creation
//		for (int i = 0; i < 25; i++) {
//			spaces[i] = new Space();
//		}
//	}
	
	//Space(front, left, right, back, valid, type)
	
	// types: 0 = null space (X), 1 = open space (O), 2 = 'boss' fight space (!!), 
	        //3 = enemy/fight space (!), 4 = item space (?),
			//5 = treasure chest space ($), 6 = exit space (>,<,v,^)
	
	//create Rooms to fit specified type
	private void createRoom1() {
		//'re-creates' each space with specialized values
		spaces[0] = new Space(null, null, spaces[1], spaces[5], true, getRandomType());
		spaces[1] = new Space(null, spaces[0], spaces[2], spaces[6], true, getRandomType());
		spaces[2] = new Space(null, spaces[1], spaces[3], spaces[7],true, getRandomType());
		spaces[3] = new Space(null, spaces[2], spaces[4], spaces[8], true, getRandomType());
		spaces[4] = new Space(null, spaces[3], null, spaces[9], true, getRandomType());
		spaces[5] = new Space(spaces[0], null, spaces[6], spaces[10], true, getRandomType());
		spaces[6] = new Space(spaces[1], spaces[5], spaces[7], spaces[11], true, getRandomType());
		spaces[7] = new Space(spaces[2], spaces[6], spaces[8], spaces[12], true, getRandomType());
		spaces[8] = new Space(spaces[3], spaces[7], spaces[9], spaces[13], true, getRandomType());
		spaces[9] = new Space(spaces[4], spaces[8], null, spaces[14], true, getRandomType());
		//spaces[10] = new Space();
		//spaces[11] = new Space(); since these spaces are null and unavailable for movement
		spaces[12] = new Space(spaces[7], null, null, spaces[17], true, getRandomType());
		//spaces[13] = new Space(); can leave them as is from the default space constructor
		//spaces[14] = new Space();
		//spaces[15] = new Space();
		//spaces[16] = new Space();
		spaces[17] = new Space(spaces[12], null, null, spaces[22], true, getRandomType());
		//spaces[18] = new Space();
		//spaces[19] = new Space();
		spaces[20] = new Space(spaces[15], null, spaces[21], null, true, getRandomType());
		spaces[21] = new Space(spaces[16], spaces[20], spaces[22], null, true, getRandomType());
		spaces[22] = new Space(spaces[17], spaces[21], spaces[23], null, true, 7);
		spaces[23] = new Space(spaces[18], spaces[22], spaces[24], null, true, getRandomType());
		spaces[24] = new Space(spaces[16], spaces[23], null, null, true, getRandomType());
	}
	
	private void createRoom2() {
		spaces[0] = new Space();
		spaces[1] = new Space();
		spaces[2] = new Space();
		spaces[3] = new Space();
		spaces[4] = new Space();
		spaces[5] = new Space();
		spaces[6] = new Space();
		spaces[7] = new Space();
		spaces[8] = new Space();
		spaces[9] = new Space();
		spaces[10] = new Space();
		spaces[11] = new Space();
		spaces[12] = new Space();
		spaces[13] = new Space();
		spaces[14] = new Space();
		spaces[15] = new Space();
		spaces[16] = new Space();
		spaces[17] = new Space();
		spaces[18] = new Space();
		spaces[19] = new Space();
		spaces[20] = new Space();
		spaces[21] = new Space();
		spaces[22] = new Space();
		spaces[23] = new Space();
		spaces[24] = new Space();
	}
	
	private void createRoom3() {
		spaces[0] = new Space();
		spaces[1] = new Space();
		spaces[2] = new Space();
		spaces[3] = new Space();
		spaces[4] = new Space();
		spaces[5] = new Space();
		spaces[6] = new Space();
		spaces[7] = new Space();
		spaces[8] = new Space();
		spaces[9] = new Space();
		spaces[10] = new Space();
		spaces[11] = new Space();
		spaces[12] = new Space();
		spaces[13] = new Space();
		spaces[14] = new Space();
		spaces[15] = new Space();
		spaces[16] = new Space();
		spaces[17] = new Space();
		spaces[18] = new Space();
		spaces[19] = new Space();
		spaces[20] = new Space();
		spaces[21] = new Space();
		spaces[22] = new Space();
		spaces[23] = new Space();
		spaces[24] = new Space();
	}
	
	private void createRoom4() {
		spaces[0] = new Space();
		spaces[1] = new Space();
		spaces[2] = new Space();
		spaces[3] = new Space();
		spaces[4] = new Space();
		spaces[5] = new Space();
		spaces[6] = new Space();
		spaces[7] = new Space();
		spaces[8] = new Space();
		spaces[9] = new Space();
		spaces[10] = new Space();
		spaces[11] = new Space();
		spaces[12] = new Space();
		spaces[13] = new Space();
		spaces[14] = new Space();
		spaces[15] = new Space();
		spaces[16] = new Space();
		spaces[17] = new Space();
		spaces[18] = new Space();
		spaces[19] = new Space();
		spaces[20] = new Space();
		spaces[21] = new Space();
		spaces[22] = new Space();
		spaces[23] = new Space();
		spaces[24] = new Space();
	}
	
	private void createRoom5() {
		spaces[0] = new Space();
		spaces[1] = new Space();
		spaces[2] = new Space();
		spaces[3] = new Space();
		spaces[4] = new Space();
		spaces[5] = new Space();
		spaces[6] = new Space();
		spaces[7] = new Space();
		spaces[8] = new Space();
		spaces[9] = new Space();
		spaces[10] = new Space();
		spaces[11] = new Space();
		spaces[12] = new Space();
		spaces[13] = new Space();
		spaces[14] = new Space();
		spaces[15] = new Space();
		spaces[16] = new Space();
		spaces[17] = new Space();
		spaces[18] = new Space();
		spaces[19] = new Space();
		spaces[20] = new Space();
		spaces[21] = new Space();
		spaces[22] = new Space();
		spaces[23] = new Space();
		spaces[24] = new Space();
	}
	
	@Override
	public String toString() {
		String res = "";
		for (int i = 0; i < 25; i++) {
			if (i % 5 == 0) { //should be making a new line every 5 spaces to show 5x5 grid
				res += "\n";
			}
			res += this.spaces[i].toString() + "\t";
		}
		return res;
	}
}