import java.util.Scanner;


public class Player {
	
	public String name;
	public int level;
	
	//default player constructor
	public Player() {
		name = "";
		level = 0;
	}
	
	public Player(String n, int l) {
		name = n;
		level = l;
	}
	
	public void createNewPlayer() {
		Scanner kb = new Scanner(System.in);
		
	}
	
	
	//public 

}
