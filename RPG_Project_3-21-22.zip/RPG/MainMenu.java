import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.text.DefaultCaret;

import java.io.IOException;

public class MainMenu extends JFrame implements KeyListener {
	
	private static final long serialVersionUID = 1L;
	
	private static JTextArea output;
	//private static Thread t1;
	//private static Thread t2;
	//private static int key = 0; //key pressed by the user
	public Game game;
	public Save data;
	
	

	public MainMenu(String name) {
		super(name);
		output = new JTextArea(50,50);
		DefaultCaret caret = (DefaultCaret) output.getCaret();
		caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
		
		//output.append(");
		
		getContentPane().add(new JScrollPane(output));
		setSize(500,500);
		setVisible(true);
		
		fillOutput();
		
		output.addKeyListener(this);
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
	}
	
	public JTextArea getOutput() {
		return output;
	}
	
	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyChar() == 'h') { //open the help menu
			HelpWindow help = new HelpWindow("Help Menu"); //open up a new help window
		}
		else if (e.getKeyChar() == 'c') {
			ControlsWindow c = new ControlsWindow("Controls Menu");
		}
		else if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
			System.exit(0);
			super.dispose();
		}
		else if (e.getKeyChar() == '1') {
			try {
				game = new Game(true); //true for continuing from a save (assuming data is available
				game.Start();
			}
			catch (Exception ex) {
				
			}
		}
		else if (e.getKeyChar() == '2') {
			try {
				game = new Game(false); 
				game.Start();
			}
			catch (Exception ex) {
				
			}
		}
	}
	
	@Override
	public void keyReleased(KeyEvent e) {
		
	}
	
	
	private void fillOutput() {
		String str = "****************************** Main Menu *****************************\n\n" + 
					"Menu Options: (press the specified key to continue)\n" +
					"--> 1 = Continue from last save (see NOTE)\n" +
					"--> 2 = New Game\n" +
					"--> h = View the help menu\n" +
					"--> c = View the game controls\n " +
					"--> esc = Exit the game\n\n" +
					
					"<---> NOTE: Will start a new save if no previous save exists <--->\n\n" +
				
					"********************** Press the esc key to exit **********************\n";
		output.append(str);
	}
	

}