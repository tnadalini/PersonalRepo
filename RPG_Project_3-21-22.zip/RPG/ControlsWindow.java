
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.text.DefaultCaret;

public class ControlsWindow extends JFrame implements KeyListener {
	
	private static final long serialVersionUID = 2L;
	
	private static JTextArea output;


	public ControlsWindow(String name) {
		super(name);
		output = new JTextArea(50,50);
		DefaultCaret caret = (DefaultCaret) output.getCaret();
		caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
		
		//output.append(");
		
		getContentPane().add(new JScrollPane(output));
		setSize(500,500);
		setVisible(true);
		fillOutput();
		
		output.addKeyListener(this);
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
	}
	
	public JTextArea getOutput() {
		return output;
	}
	
	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyChar() == 'c') {
			super.dispose(); //will close this window upon h key being pressed
		}
	}
	
	@Override
	public void keyReleased(KeyEvent e) {
		//output.append("" + e.getKeyChar() + "\n");
	}
	
	// types: 0 = null space (X), 1 = open space (O), 2 = 'boss' fight space (!!), 
	//3 = enemy/fight space (!), 4 = item space (?),
	//5 = treasure chest space ($), 6 = exit space (>,<,v,^)
	private void fillOutput() {
		String str = "****************************** Game Controls ******************************\n\n" + 
					"Movement Controls: \n" +
					"--> W = move one space forward/up\n" +
					"--> A = move one space to the left\n" +
					"--> S = move one space backward/down\n" +
					"--> D = move one space to the right\n\n " +
				
					"************************* Press the c key to exit *************************\n";
		output.append(str);
	}

}