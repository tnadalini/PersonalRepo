
public class main1 {
	
	public static void main(String[] args) {
		
		//MapWindow map = new MapWindow("GameMap");
		//HelpWindow help = new HelpWindow("Help Menu");
		//Room r = new Room(1);
		//map.get(r.toString());
		//System.out.println(r.toString());
		//map.getOutput().append(r.toString());
		MainMenu m = new MainMenu("Main_Menu");
	}
	
}
