import java.io.File;
import java.io.IOException;
import java.util.Scanner;


public class Save {
	
	public boolean save; //true if save file exists, false if not
	public File file;
	//public Player player;
	
	public String[] data = new String[2];
	
	//public Save(Player p) { 
	//	this.player = p;
	//}
	
	public void checkSave() {
		file = new File("savedata.txt");
		this.save = file.exists();
	}
	
	public void readFile() throws IOException {
		checkSave();
		if (save != true) {
			return;
		}
		//else save file exists

		try {
			Scanner scan = new Scanner(new File("savedata.txt"));
			int count = 0;
			while (scan.hasNextLine()) {
				data[count] = scan.nextLine();
				count++;
			}
		}
		catch (Exception e) {
			System.out.println("File Doesn't exist or can't be read properly");		
		}
	}
	
	public void deleteFile() { //delete the current save file 
		file.delete();
	}
	
}
