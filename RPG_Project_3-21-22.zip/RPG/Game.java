import java.io.IOException;

public class Game {
	
	public Dungeon d;
	public Save save;
	public Player player;
	public boolean cont; //continue
	
	MapWindow map;
	
	public Game(boolean boo) {
		cont = boo;
	}
	
	public void Start() throws IOException { //run to start-up the 'game' processes
		//check if save file exists using Save class
		save = new Save();
		save.checkSave();
		if (save.save == true) { //previous save file exists
			contSave();
		}
		else { //save.save == false
			newGame();
		}
		
	}
	
	
	public void newDungeon() {
		
		//for new will create a 1 room dungeon, containing a single room of type 1
		d = new Dungeon(1);
		
		player = new Player();
		player.createNewPlayer();
		
		map = new MapWindow("GameMap", player, this); 
		 map.getOutput().append("*************************************" +
				 				"*************************************");
		 map.getOutput().append(d.rooms[0].toString() + "\n");
	}
	
	private void contSave() throws IOException {
		save.readFile();
		player = new Player(save.data[0], Integer.parseInt(save.data[1])); //create a new Player using the old data
		newDungeon(); //just for testing
	}
	
	private void newGame() {
		
	}

}
