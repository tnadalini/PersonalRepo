
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.text.DefaultCaret;

public class HelpWindow extends JFrame implements KeyListener {
	
	private static final long serialVersionUID = 2L;
	
	private static JTextArea output;


	public HelpWindow(String name) {
		super(name);
		output = new JTextArea(50,50);
		DefaultCaret caret = (DefaultCaret) output.getCaret();
		caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
		
		//output.append(");
		
		getContentPane().add(new JScrollPane(output));
		setSize(500,500);
		setVisible(true);
		fillOutput();
		
		output.addKeyListener(this);
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
	}
	
	public JTextArea getOutput() {
		return output;
	}
	
	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyChar() == 'h') {
			super.dispose(); //will close this window upon h key being pressed
		}
		else if (e.getKeyChar() == 'c') {
			ControlsWindow c = new ControlsWindow("Controls Menu");
		}
		else if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
			System.exit(0);
			super.dispose();
		}
	}
	
	@Override
	public void keyReleased(KeyEvent e) {
		//output.append("" + e.getKeyChar() + "\n");
	}
	
	// types: 0 = null space (X), 1 = open space (O), 2 = 'boss' fight space (!!), 
	//3 = enemy/fight space (!), 4 = item space (?),
	//5 = treasure chest space ($), 6 = exit space (>,<,v,^)
	private void fillOutput() {
		String str = "****************************** Help Menu ******************************\n\n" + 
					"<------> Press the c key to view the game controls <------>\n\n" +
					"Symbols: \n" + 
					"--> P = player space: the player's current location in the room\n" +
					"--> X = null space: player movement restricted\n" +
					"--> O = open space: player movement possible\n" + 
					"--> !! = boss fight space: boss-type battle at this location\n" +
					"--> ! = enemy fight space: standard battle at this location\n" + 
					"--> ? = random item space: random item pick-up available\n" +
					"--> $ = treasure chest space: chest (possibly) containing multiple items\n" +
					"--> >,< = exit space: move to this location to leave the room/dungeon\n\n" +
					"******************* Press h key to exit the help menu ******************\n" +
					"\n**** Press the esc key to exit the game (data will not be saved!) ****\n";
		output.append(str);
	}

}